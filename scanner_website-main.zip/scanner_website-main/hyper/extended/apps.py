from django.apps import AppConfig


class ExtendedConfig(AppConfig):
    name = 'hyper.extended'
