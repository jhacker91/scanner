from django.apps import AppConfig


class UiConfig(AppConfig):
    name = 'hyper.ui'
