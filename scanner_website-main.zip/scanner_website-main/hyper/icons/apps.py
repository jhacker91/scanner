from django.apps import AppConfig


class IconsConfig(AppConfig):
    name = 'hyper.icons'
