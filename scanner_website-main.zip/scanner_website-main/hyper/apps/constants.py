CATEGORY_DANGER = "bg-danger"
CATEGORY_SUCCESS = "bg-success"
CATEGORY_PRIMARY = "bg-primary"
CATEGORY_INFO = "bg-info"
CATEGORY_DARK = "bg-dark"
CATEGORY_WARNING = "bg-warning"
CATEGORY_CHOICES = [
    (CATEGORY_DANGER, "Danger"),
    (CATEGORY_SUCCESS, "Success"),
    (CATEGORY_PRIMARY, "Primary"),
    (CATEGORY_INFO, "Info"),
    (CATEGORY_DARK, "Dark"),
    (CATEGORY_WARNING, "Warning"),
]
